﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GADE_6112_Assignment2
{
    class FactoryBuilding : Building
    {
        private int unitsToProduce;
        private int unitsPerTick;
        private int spawnPointX;
        private int spawnPointY;

        
        public FactoryBuilding(int x, int y, int health, string faction, string symbol, int unitsToProduce, int unitsPerTick, int spawnPointX, int spawnPointY)
            : base(x, y, health, faction, symbol)
        {
            this.unitsToProduce = unitsToProduce;
            this.unitsPerTick = unitsPerTick;
            this.spawnPointX = spawnPointX;
            this.spawnPointY = spawnPointY;
        }


        public Unit spawnNewUnit()
        {
            if(unitsToProduce > 0)
            {
                MeleeUnit mU = new MeleeUnit(spawnPointX, spawnPointY, 100, -1, true, 1, this.faction, "M", "SwordsMan");
                unitsToProduce--;
                return mU;
            }
            else
            {
                RangedUnit rU = new RangedUnit(spawnPointX, spawnPointY, 100, -1, true, 1, this.faction, "R", "Gunner");
                unitsToProduce--;
                return rU;
            }
        }
        
        //public override bool isAlive()
        //{
        //    if (this.Health <= 0)
        //        return false;
        //    else
        //        return true;

        //}
        
        public override string toString()
        {
            string output
            = "x : " + X + Environment.NewLine
            + "y : " + Y + Environment.NewLine
            + "Health : " + Health + Environment.NewLine
            + "Faction : " + Team + Environment.NewLine
            + "Symbol : " + Symbol + Environment.NewLine
            + "Units To Produce" + unitsToProduce + Environment.NewLine
            + "Spawn Point X" + spawnPointX + Environment.NewLine
            + "Spawn Point Y" + spawnPointY + Environment.NewLine;
            return output;
        }
        public override void save()
        {
            FileStream outFile = null;
            StreamWriter writer = null;
            try
            {
                outFile = new FileStream(@"File\FactoryBuilding.txt", FileMode.Append, FileAccess.Write);
                writer = new StreamWriter(outFile);
                writer.WriteLine(x);
                writer.WriteLine(y);
                writer.WriteLine(health);
                writer.WriteLine(symbol);
                writer.WriteLine(unitsToProduce);
                writer.WriteLine(unitsPerTick);
                writer.WriteLine(spawnPointX);
                writer.WriteLine(spawnPointY);
                writer.Close();
                outFile.Close();
            }
            catch (IOException fe)
            {
                Console.WriteLine("Error: " + fe.Message);
            }
            finally
            {
                if (writer != null)
                    writer.Close();
                if (outFile != null)
                    outFile.Close();
            }            
        }
    }
}
