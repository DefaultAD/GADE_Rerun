﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GADE_6112_Assignment2
{
    abstract class Building
    {
        protected int x;
        protected int y;
        protected int health;
        protected string faction;
        protected string symbol;

        #region Accessors 
        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        public string Team
        {
            get { return faction; }
            set { faction = value; }
        }
        
        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }
        #endregion

        public Building(int x, int y, int health, string faction, string symbol)
        {
            this.x = x;
            this.y = y;
            this.Health = health;
            this.faction = faction;
            this.Symbol = symbol;
        }

        ~Building()
        {
        }

        public virtual bool isAlive()
        {
            return true;
        }
        
        public virtual string toString()
        {
            string output = "X : " + x + Environment.NewLine
            + "Y : " + y + Environment.NewLine
            + "Health : " + Health + Environment.NewLine
            + "Team : " + Team + Environment.NewLine
            + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }
        public abstract void save();
    }
}


