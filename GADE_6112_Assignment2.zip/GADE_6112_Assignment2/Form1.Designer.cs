﻿namespace GADE_6112_Assignment2
{
    partial class RTS_Simulator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelGameTime = new System.Windows.Forms.Label();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonPause = new System.Windows.Forms.Button();
            this.timerTicks = new System.Windows.Forms.Timer(this.components);
            this.labelMap = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelStats = new System.Windows.Forms.Label();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // labelGameTime
            // 
            this.labelGameTime.AutoSize = true;
            this.labelGameTime.Location = new System.Drawing.Point(244, 27);
            this.labelGameTime.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.labelGameTime.Name = "labelGameTime";
            this.labelGameTime.Size = new System.Drawing.Size(33, 13);
            this.labelGameTime.TabIndex = 1;
            this.labelGameTime.Text = "Ticks";
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(352, 19);
            this.buttonStart.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(153, 29);
            this.buttonStart.TabIndex = 3;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonPause
            // 
            this.buttonPause.Location = new System.Drawing.Point(352, 64);
            this.buttonPause.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.buttonPause.Name = "buttonPause";
            this.buttonPause.Size = new System.Drawing.Size(153, 29);
            this.buttonPause.TabIndex = 4;
            this.buttonPause.Text = "Pause";
            this.buttonPause.UseVisualStyleBackColor = true;
            this.buttonPause.Click += new System.EventHandler(this.buttonPause_Click);
            // 
            // timerTicks
            // 
            this.timerTicks.Enabled = true;
            this.timerTicks.Tick += new System.EventHandler(this.timerTicks_Tick);
            // 
            // labelMap
            // 
            this.labelMap.AutoSize = true;
            this.labelMap.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelMap.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMap.Location = new System.Drawing.Point(18, 45);
            this.labelMap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelMap.MaximumSize = new System.Drawing.Size(338, 419);
            this.labelMap.MinimumSize = new System.Drawing.Size(272, 398);
            this.labelMap.Name = "labelMap";
            this.labelMap.Size = new System.Drawing.Size(272, 398);
            this.labelMap.TabIndex = 0;
            this.labelMap.Click += new System.EventHandler(this.labelMap_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(352, 194);
            this.buttonExit.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(153, 29);
            this.buttonExit.TabIndex = 5;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelStats
            // 
            this.labelStats.AutoSize = true;
            this.labelStats.Location = new System.Drawing.Point(350, 252);
            this.labelStats.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.labelStats.MaximumSize = new System.Drawing.Size(188, 335);
            this.labelStats.MinimumSize = new System.Drawing.Size(150, 210);
            this.labelStats.Name = "labelStats";
            this.labelStats.Size = new System.Drawing.Size(150, 210);
            this.labelStats.TabIndex = 6;
            this.labelStats.Click += new System.EventHandler(this.labelStats_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Location = new System.Drawing.Point(352, 110);
            this.buttonSave.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(153, 29);
            this.buttonSave.TabIndex = 7;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonLoad
            // 
            this.buttonLoad.Location = new System.Drawing.Point(352, 153);
            this.buttonLoad.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(153, 29);
            this.buttonLoad.TabIndex = 8;
            this.buttonLoad.Text = "Load";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // RTS_Simulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 459);
            this.Controls.Add(this.buttonLoad);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.labelStats);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonPause);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.labelGameTime);
            this.Controls.Add(this.labelMap);
            this.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.Name = "RTS_Simulator";
            this.Text = "GADE6112_Assignment2";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelGameTime;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonPause;
        private System.Windows.Forms.Timer timerTicks;
        private System.Windows.Forms.Label labelMap;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label labelStats;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

