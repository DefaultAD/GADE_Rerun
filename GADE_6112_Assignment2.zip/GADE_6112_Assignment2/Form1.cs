﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace GADE_6112_Assignment2
{
    
    public partial class RTS_Simulator : Form
    {
        GameEngine engine = new GameEngine();
        
        public RTS_Simulator()

        {            
            InitializeComponent();
            
        }
               
        private void Form1_Load(object sender, EventArgs e)
        {
            timerTicks.Enabled = false;
        }
        
        private void buttonPause_Click(object sender, EventArgs e)
        {
            buttonPause.Enabled = false;
            buttonStart.Enabled = true;
            timerTicks.Enabled = false;
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            buttonStart.Enabled = false;
            buttonPause.Enabled = true;
            timerTicks.Enabled = true;            
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.DialogResult result = MessageBox.Show("Be back soon!");
            if (result == DialogResult.OK)
                Application.Exit();
        }

        private void timerTicks_Tick(object sender, EventArgs e)
        {
            labelGameTime.Text = System.DateTime.Now.ToLongTimeString();

            engine.start();

            labelMap.Text = " ";            
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    labelMap.Text += engine.map.Grid[i, j] + " ";
                }
                labelMap.Text += "\n";
            }
        }

        private void labelStats_Click(object sender, EventArgs e)
        {
            
        }

        private void labelMap_Click(object sender, EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;

            int mapX = labelMap.Location.X;
            int mapY = labelMap.Location.Y;

            int y = (mouseX - mapX - 39 - 6) / 15;
            int x = (mouseY - mapY - 70 - 1) / 15;

            labelStats.Text = "";
            foreach (Unit u in engine.map.UnitsOnMap)
            {
                if (u.X == x && u.Y == y)
                    {
                    labelStats.Text = u.toString();
                    }
            }
            foreach (Building u in engine.map.BuildingsOnMap)
            {
                if (u.X == x && u.Y == y)
                    labelStats.Text = u.toString();
            }
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            
            engine.map.LoadFromList();
            labelMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    labelMap.Text += engine.map.Grid[i, j] + " ";
                }
                labelMap.Text += "\n";
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            
        }
    }   
}



