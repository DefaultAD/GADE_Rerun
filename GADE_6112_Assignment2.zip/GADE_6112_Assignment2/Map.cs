﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GADE_6112_Assignment2
{
    class Map
    {

        private const int maxRndUnits = 50;
        private const string fieldSymbol = " .";
        private string[,] grid = new string[20, 20];
        private List<Unit> unitsOnMap = new List<Unit>();
        private int numberOfUnitsOnMap = 0;

        private const int maxRndBuildings = 20;
        private List<Building> buildingsOnMap = new List<Building>();
        private int numberOfBuildingsOnMap = 0;

        ResourceBuilding redbuilding = new ResourceBuilding(0, 0, 1000, "Red", "#");
        ResourceBuilding greenbuilding = new ResourceBuilding(19, 19, 1000, "Green", "#");
        FactoryBuilding redfactory = new FactoryBuilding(19, 0, 1000, "Red", "@", 1, 1, 20, 1);
        FactoryBuilding greenfactory = new FactoryBuilding(0, 19, 1000, "Green", "@", 1, 1, 1, 20);

        public ResourceBuilding Redbuilding
        {
            get { return redbuilding; }
            set { redbuilding = value; }
        }

        public ResourceBuilding Greenbuilding
        {
            get { return greenbuilding; }
            set { greenbuilding = value; }
        }

        public FactoryBuilding Redfactory
        {
            get { return redfactory; }
            set { redfactory = value; }
        }

        public FactoryBuilding Greenfactory
        {
            get { return greenfactory; }
            set { greenfactory = value; }
        }

        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }

        public List<Unit> UnitsOnMap
        {
            get
            {
                return unitsOnMap;
            }
        }
        public List<Building> BuildingsOnMap
        {
            get
            {
                return buildingsOnMap;
            }
        }

        public void LoadFromList()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = fieldSymbol;
                }
            }

            int x, y;

            x = redbuilding.X;
            y = redbuilding.Y;
            grid[x, y] = redbuilding.Symbol;

            x = greenbuilding.X;
            y = greenbuilding.Y;
            grid[x, y] = greenbuilding.Symbol;

            x = redfactory.X;
            y = redfactory.Y;
            grid[x, y] = redfactory.Symbol;

            x = greenfactory.X;
            y = greenfactory.Y;
            grid[x, y] = greenfactory.Symbol;

            foreach (Unit u in UnitsOnMap)
            {
                x = u.X;
                y = u.Y;

                grid[x, y] = u.Symbol;
            }
        }        

        public void Populate()
        {
            Random rnd = new Random();
            int numberRndUnits = rnd.Next(0, maxRndUnits + 1);
            int numberRndBuildings = rnd.Next(0, maxRndBuildings + 1);
            int x, y, rndAtkRange;
            bool attackOption;
            bool buildingType;
            string teams;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = fieldSymbol;
                }
            }

            x = redbuilding.X;
            y = redbuilding.Y;
            grid[x, y] = redbuilding.Symbol;

            x = greenbuilding.X;
            y = greenbuilding.Y;
            grid[x, y] = greenbuilding.Symbol;

            x = redfactory.X;
            y = redfactory.Y;
            grid[x, y] = redfactory.Symbol;

            x = greenfactory.X;
            y = greenfactory.Y;
            grid[x, y] = greenfactory.Symbol;

            for (int k = 1; k <= numberRndUnits; k++)
            {
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                } while (grid[x, y] != fieldSymbol);

                if (rnd.Next(1, 3) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    teams = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Unit tmp = new MeleeUnit(x, y, 100, -1, attackOption, 1, teams, "M", "Griever");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = tmp.Symbol;

                    numberOfUnitsOnMap++;
                }

                else if (rnd.Next(1, 4) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    rndAtkRange = rnd.Next(1, 20);
                    teams = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Unit tmp = new RangedUnit(x, y, 100, -1, attackOption, rndAtkRange, teams, "R", "Camper");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = unitsOnMap[numberOfUnitsOnMap].Symbol;

                    numberOfUnitsOnMap++;
                }
                else 

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = fieldSymbol;
                }
            }
            for (int l = 1; l <= numberRndBuildings; l++)
            {
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                } while (grid[x, y] != fieldSymbol);
                    
                if (rnd.Next(1, 5) == 1)
                    {
                    buildingType = rnd.Next(0, 2) == 1 ? true : false;
                    teams = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Building tmp = new ResourceBuilding(x, y, 100, teams, "@");
                    buildingsOnMap.Add(tmp);

                    grid[x, y] = buildingsOnMap[numberOfBuildingsOnMap].Symbol;

                    numberOfBuildingsOnMap++;
                    }
                else
                    {
                    buildingType = rnd.Next(0, 2) == 1 ? true : false;
                    teams = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Building tmp = new FactoryBuilding(x, y, 100, teams, "#", 1, 1, 20, 1);
                    buildingsOnMap.Add(tmp);

                    grid[x, y] = buildingsOnMap[numberOfBuildingsOnMap].Symbol;

                    numberOfBuildingsOnMap++;
                    }
            }
        }
    }

        private void moveOnMap(Unit u, int newX, int newY)
        {
            grid[u.X, u.Y] = fieldSymbol;
            grid[newX, newY] = u.Symbol;
           
        }

        public void update(Unit u, int newX, int newY)
        {
            if ((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            {
                moveOnMap(u, newX, newY);
                u.move(newX, newY);
            }
        }

        public void CheckHealth()
        {
            for (int i = 0; i < numberOfUnitsOnMap; i++)
            {
                if (!unitsOnMap[i].isAlive())
                {
                    grid[unitsOnMap[i].X, unitsOnMap[i].Y] = fieldSymbol;
                    unitsOnMap.RemoveAt(i);
                    numberOfUnitsOnMap--;
                }
            }
            for (int i = 0; i < numberOfBuildingsOnMap; i++)
            {
                if (!buildingsOnMap[i].isAlive())
                {
                    grid[buildingsOnMap[i].X, buildingsOnMap[i].Y] = fieldSymbol;
                    buildingsOnMap.RemoveAt(i);
                    numberOfBuildingsOnMap--;
                }
            }
        }

        

    }
}     