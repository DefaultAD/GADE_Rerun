﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_Rerun_Resub_16030606
{
    abstract class Unit
    {
        private int x;
        private int y;
        private int health;
        private int speed;
        private int attackRange;
        private bool attack;
        private string team;
        private string symbol;

        #region Accessors
        public int X
        {
            get { return x; }
            set { x = value; }
        }
        public int Y
        {
            get { return y; }
            set { y = value; }
        }
        public int Health
        {
            get { return health; }
            set { health = value; }
        }
        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }
        public int AttackRange
        {
            get { return attackRange; }
            set { attackRange = value; }
        }
        public bool Attack
        {
            get { return attack; }
            set { attack = value; }
        }
        public string Team
        {
            get { return team; }
            set { team = value; }
        }
        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; }
        }
        #endregion


        public Unit(int x, int y, int health, int speed, bool attack, int attackRange, string team, string symbol)
        {
            this.x = x;
            this.y = y;
            this.health = health;
            this.speed = speed;
            this.attack = attack;
            this.attackRange = attackRange;
            this.team = team;
            this.symbol = symbol;
        }

        ~Unit()
        {
        }

        public abstract void move(int x, int y);
        public abstract void combat(Unit enemy);
        public abstract bool isWithinAttackRange(Unit enemy);
        public abstract Unit closestUnit(List<Unit> u);
        public abstract bool isAlive();
        public abstract string toString();
    }
}







