﻿namespace Assignment1_Rerun_Resub_16030606
{
    partial class RTS_Simulator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelStats = new System.Windows.Forms.Label();
            this.buttonPause = new System.Windows.Forms.Button();
            this.buttonStart = new System.Windows.Forms.Button();
            this.labelGameTime = new System.Windows.Forms.Label();
            this.labelMap = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelStats
            // 
            this.labelStats.AutoSize = true;
            this.labelStats.Location = new System.Drawing.Point(753, 517);
            this.labelStats.MaximumSize = new System.Drawing.Size(501, 799);
            this.labelStats.MinimumSize = new System.Drawing.Size(400, 501);
            this.labelStats.Name = "labelStats";
            this.labelStats.Size = new System.Drawing.Size(400, 501);
            this.labelStats.TabIndex = 14;
            this.labelStats.Click += new System.EventHandler(this.labelStats_Click_1);
            // 
            // buttonPause
            // 
            this.buttonPause.Location = new System.Drawing.Point(745, 177);
            this.buttonPause.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonPause.Name = "buttonPause";
            this.buttonPause.Size = new System.Drawing.Size(408, 69);
            this.buttonPause.TabIndex = 12;
            this.buttonPause.Text = "Pause";
            this.buttonPause.UseVisualStyleBackColor = true;
            this.buttonPause.Click += new System.EventHandler(this.buttonPause_Click_1);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(745, 69);
            this.buttonStart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(408, 69);
            this.buttonStart.TabIndex = 11;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click_1);
            // 
            // labelGameTime
            // 
            this.labelGameTime.AutoSize = true;
            this.labelGameTime.Location = new System.Drawing.Point(609, 26);
            this.labelGameTime.Name = "labelGameTime";
            this.labelGameTime.Size = new System.Drawing.Size(81, 32);
            this.labelGameTime.TabIndex = 10;
            this.labelGameTime.Text = "Ticks";
            // 
            // labelMap
            // 
            this.labelMap.AutoSize = true;
            this.labelMap.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.labelMap.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMap.Location = new System.Drawing.Point(6, 69);
            this.labelMap.Margin = new System.Windows.Forms.Padding(11, 0, 11, 0);
            this.labelMap.MaximumSize = new System.Drawing.Size(901, 999);
            this.labelMap.MinimumSize = new System.Drawing.Size(725, 949);
            this.labelMap.Name = "labelMap";
            this.labelMap.Size = new System.Drawing.Size(725, 949);
            this.labelMap.TabIndex = 9;
            this.labelMap.Click += new System.EventHandler(this.labelMap_Click_1);
            // 
            // RTS_Simulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1170, 1027);
            this.Controls.Add(this.labelStats);
            this.Controls.Add(this.buttonPause);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.labelGameTime);
            this.Controls.Add(this.labelMap);
            this.Name = "RTS_Simulator";
            this.Text = "RST Simulator";
            this.Load += new System.EventHandler(this.RTS_Simulator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelStats;
        private System.Windows.Forms.Button buttonPause;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Label labelGameTime;
        private System.Windows.Forms.Label labelMap;
    }
}

