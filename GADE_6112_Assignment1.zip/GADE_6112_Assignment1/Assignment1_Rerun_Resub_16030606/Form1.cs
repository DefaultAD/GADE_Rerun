﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment1_Rerun_Resub_16030606
{
    public partial class RTS_Simulator : Form
    {
        GameEngine engine = new GameEngine();

        public RTS_Simulator()
        {
            InitializeComponent();
        }

        private void timerTicks_Tick(object sender, EventArgs e)
        {
            labelGameTime.Text = System.DateTime.Now.ToLongTimeString();

            engine.start();

            labelMap.Text = " ";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    labelMap.Text += engine.map.Grid[i, j] + " ";
                }
                labelMap.Text += "\n";
            }
        }
        
        private void buttonStart_Click_1(object sender, EventArgs e)
        {
            buttonStart.Enabled = false;
            buttonPause.Enabled = true;
        }

        private void buttonPause_Click_1(object sender, EventArgs e)
        {
            buttonPause.Enabled = false;
            buttonStart.Enabled = true;
        }
                
        private void labelMap_Click_1(object sender, EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;

            int mapX = labelMap.Location.X;
            int mapY = labelMap.Location.Y;

            int y = (mouseX - mapX - 39 - 6) / 15;
            int x = (mouseY - mapY - 70 - 1) / 15;

            labelStats.Text = "";
            foreach (Unit u in engine.map.UnitsOnMap)
            {
                if (u.X == x && u.Y == y)
                {
                    labelStats.Text = u.toString();
                }
            }
        }

        private void labelStats_Click_1(object sender, EventArgs e)
        {

        }

        private void RTS_Simulator_Load(object sender, EventArgs e)
        {
         
        }
    }
}




