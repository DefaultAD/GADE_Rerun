﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_Rerun_Resub_16030606
{
    class Map
    {

        private const int maxRndUnits = 50;
        private const string fieldSymbol = " .";
        private string[,] grid = new string[20, 20];
        private List<Unit> unitsOnMap = new List<Unit>();
        private int numberOfUnitsOnMap = 0;
               
        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }

        public List<Unit> UnitsOnMap
        {
            get
            {
                return unitsOnMap;
            }
        }
       
        public void LoadFromList()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = fieldSymbol;
                }
            }

            int x, y;
            
            foreach (Unit u in UnitsOnMap)
            {
                x = u.X;
                y = u.Y;

                grid[x, y] = u.Symbol;
            }
        }

        public void Populate()
        {
            Random rnd = new Random();
            int numberRndUnits = rnd.Next(0, maxRndUnits + 1);
            int x, y, rndAtkRange;
            bool attackOption;
            string teams;

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = fieldSymbol;
                }
            }


            for (int k = 1; k <= numberRndUnits; k++)
            {
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                } while (grid[x, y] != fieldSymbol);

                if (rnd.Next(1, 3) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    teams = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Unit tmp = new MeleeUnit(x, y, 100, -1, attackOption, 1, teams, "M");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = tmp.Symbol;

                    numberOfUnitsOnMap++;
                }

                else if (rnd.Next(1, 4) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    rndAtkRange = rnd.Next(1, 20);
                    teams = rnd.Next(0, 2) == 1 ? "RED" : "GREEN";
                    Unit tmp = new RangedUnit(x, y, 100, -1, attackOption, rndAtkRange, teams, "R");
                    unitsOnMap.Add(tmp);

                    grid[x, y] = unitsOnMap[numberOfUnitsOnMap].Symbol;

                    numberOfUnitsOnMap++;
                }
                else

                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        grid[i, j] = fieldSymbol;
                    }
                }                
            }
        }

        private void moveOnMap(Unit u, int newX, int newY)
        {
            grid[u.X, u.Y] = fieldSymbol;
            grid[newX, newY] = u.Symbol;

        }

        public void update(Unit u, int newX, int newY)
        {
            if ((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            {
                moveOnMap(u, newX, newY);
                u.move(newX, newY);
            }
        }

        public void CheckHealth()
        {
            for (int i = 0; i < numberOfUnitsOnMap; i++)
            {
                if (!unitsOnMap[i].isAlive())
                {
                    grid[unitsOnMap[i].X, unitsOnMap[i].Y] = fieldSymbol;
                    unitsOnMap.RemoveAt(i);
                    numberOfUnitsOnMap--;
                }
            }            
        }
    }
}
